# 화면설계 Description 작성 및 번호 매핑 Skill

## 개요

Figma 화면을 분석하여 디자인/퍼블리싱 요청과 기능 개발 요청으로 구분된 Description을 작성하고,
화면 위에 항목별 위치를 번호 배지로 표시하는 워크플로우다.

---

## 적용 조건

다음 요청에 이 skill을 사용한다:
- "디스크립션 작성해줘"
- "화면 분석해서 설명 만들어줘"
- "Description 내용 만들어줘"
- "화면에 번호 표시해줘"
- "화면설계서 작성" 관련 요청

---

## 핵심 원칙

### 1. 반복 정의 금지 (가장 중요)

- 이미 다른 화면에서 정의한 항목은 동일하게 재정의하지 않는다
- 작업 시작 전 반드시 이전 화면들의 Description 내용을 확인한다
- 신규 화면에서 처음 등장하는 UI/기능 요소만 정의한다
- 동일 컴포넌트라도 상태(state), 조건(condition), 흐름(flow)이 다르면 정의 가능

**판단 기준표:**

| 상황 | 정의 여부 |
|---|---|
| 이전 화면에서 동일 컴포넌트, 동일 상태 | ❌ 제외 |
| 이전 화면에서 등장했으나 이 화면에서 신규 상태 | ✅ 포함 |
| 이 화면에서 처음 등장하는 컴포넌트 | ✅ 포함 |
| 이전과 동일하나 위치/레이아웃이 다른 경우 | △ 기획 판단 필요 |

### 2. 사용자/관리자 화면 분리

- 사용자(User) 화면과 관리자(Admin) 화면은 반드시 분리하여 분석
- Description 항목에 대상 화면 명시

### 3. 관점 분리

- **디자인/퍼블리싱**: 시각 스타일, 레이아웃, 컴포넌트 구조, 상태별 스타일
- **기능 개발**: 사용자 인터랙션, API 연동, 상태 전환, 유효성 검증, 라우팅

---

## 워크플로우

### Step 1: 화면 파악

```
도구: get_design_context (fileKey, nodeId)
목적: 화면 구조, 컴포넌트 구성, 텍스트 내용 파악
```

- Figma URL에서 fileKey, nodeId 추출 (node-id의 `-`는 `:`로 변환)
- 화면 정보 확인: 화면명, 화면ID, 화면경로, 시스템명
- 스크린샷으로 UI 요소 위치 파악

### Step 2: 기존 정의 확인 (반복 금지 적용)

이전 화면들의 Description 내용을 확인하고 다음을 파악한다:
- 이미 정의된 컴포넌트 목록
- 이미 정의된 기능 목록
- 신규 화면에서만 등장하는 요소

### Step 3: Description 항목 도출

**분석 순서:**
1. 화면 상단 → 하단 순으로 스캔
2. 전체 레이아웃 구조 파악
3. 신규 컴포넌트/패턴 추출
4. 신규 인터랙션/기능 추출
5. 이전 정의 항목 제거

**항목 작성 기준:**
- 개조식 문체 사용
- 괄호 안에 세부 사항 명시: `카테고리 카드 컴포넌트 (아이콘 영역 + 텍스트, 2열 그리드)`
- 디자인과 기능은 1:1 대응이 아니어도 됨 (각각 독립적으로 도출)
- 권장 항목 수: 각 6개 내외 (화면 복잡도에 따라 조정)

### Step 4: Figma Description 섹션에 항목 작성

**대상 노드 확인:**
- 좌측 컨테이너 (디자인요청): `findAll(n => n.name.includes('디자인요청'))`
- 우측 컨테이너 (기능개발요청): `findAll(n => n.name.includes('기능개발요청'))`
- 각 컨테이너 내 첫 번째 항목 노드를 템플릿으로 사용

**use_figma 스크립트 패턴:**

```javascript
// 1. 페이지 전환 먼저
let pageNode = targetNode;
while (pageNode.type !== 'PAGE') pageNode = pageNode.parent;
await figma.setCurrentPageAsync(pageNode);

// 2. 폰트 사용 가능 여부 확인 후 로드
const allFonts = await figma.listAvailableFontsAsync();
const hasPretendard = allFonts.some(f => f.fontName.family === 'Pretendard');
const contentFont = hasPretendard
  ? { family: 'Pretendard', style: 'Regular' }
  : { family: 'Inter', style: 'Regular' };
await figma.loadFontAsync(contentFont);
await figma.loadFontAsync({ family: 'Roboto', style: 'Medium' });

// 3. 항목 업데이트 함수
function updateItem(itemNode, number, text) {
  const textNodes = itemNode.findAll(n => n.type === 'TEXT');
  if (textNodes.length >= 1) {
    textNodes[0].fontName = { family: 'Roboto', style: 'Medium' };
    textNodes[0].characters = String(number);
  }
  if (textNodes.length >= 2) {
    textNodes[1].fontName = contentFont;
    textNodes[1].characters = text;
  }
}

// 4. 항목 1 업데이트
updateItem(leftItemTemplate, 1, leftItems[0]);
updateItem(rightItemTemplate, 1, rightItems[0]);

// 5. 2번 이후 항목 clone & append
for (let i = 1; i < leftItems.length; i++) {
  const clone = leftItemTemplate.clone();
  updateItem(clone, i + 1, leftItems[i]);
  leftContainer.appendChild(clone);
}
```

**노드 구조 (표준 템플릿):**
```
컨테이너 (flex-col)
└── 1번 항목 (flex-row)
    ├── 번호 배지 (w:62px, bg:#1371ee 또는 #ffa800)
    │   └── TEXT "1" (Roboto Medium 34px)
    └── 내용 셀 (flex:1)
        └── TEXT "내용" (Pretendard/Inter Regular 26px)
```

### Step 5: 화면에 번호 배지 배치

**사전 작업: 화면 이미지 스크린샷 분석**
```javascript
// 이미지 노드 스크린샷으로 요소 위치 파악
const imgNode = await figma.getNodeByIdAsync('IMAGE_NODE_ID');
await imgNode.screenshot({ scale: 1 });
```

**위치 계산 공식:**
```
이미지 노드 위치: left(L), top(T), width(W), height(H)
이미지 내 요소 좌표: (ix, iy)  ← 스크린샷 분석으로 추정

프레임 내 배지 좌표:
  badge_x = L + ix
  badge_y = T + iy

디자인 배지 기본 x: L + 15  (화면 좌측)
기능개발 배지 기본 x: L + W - 80  (화면 우측)
```

**배지 생성 패턴:**

```javascript
await figma.loadFontAsync({ family: 'Roboto', style: 'Medium' });

const BADGE_SIZE = 64;
const BLUE   = { r: 19/255, g: 113/255, b: 238/255 }; // #1371ee
const ORANGE = { r: 255/255, g: 168/255, b: 0 };       // #ffa800
const WHITE  = { r: 1, g: 1, b: 1 };

function createBadge(parent, num, cx, cy, bgColor) {
  const circle = figma.createEllipse();
  circle.resize(BADGE_SIZE, BADGE_SIZE);
  circle.x = cx - BADGE_SIZE / 2;
  circle.y = cy - BADGE_SIZE / 2;
  circle.fills = [{ type: 'SOLID', color: bgColor }];
  circle.name = `annot-badge-${num}`;

  const txt = figma.createText();
  txt.fontName = { family: 'Roboto', style: 'Medium' };
  txt.fontSize = 30;
  txt.characters = String(num);
  txt.fills = [{ type: 'SOLID', color: WHITE }];
  txt.textAlignHorizontal = 'CENTER';
  txt.textAlignVertical = 'CENTER';
  txt.resize(BADGE_SIZE, BADGE_SIZE);
  txt.x = cx - BADGE_SIZE / 2;
  txt.y = cy - BADGE_SIZE / 2;

  parent.appendChild(circle);
  parent.appendChild(txt);
  return [circle.id, txt.id];
}

// 사용 예시
for (const b of designBadges) {
  createBadge(mainFrame, b.num, b.x, b.y, BLUE);
}
for (const b of devBadges) {
  createBadge(mainFrame, b.num, b.x, b.y, ORANGE);
}
```

**주요 UI 요소별 배지 y 비율 가이드 (모바일 챗봇 화면 기준):**

| UI 요소 | 이미지 내 y 비율 | 비고 |
|---|---|---|
| 헤더 영역 | ~8% | 타이틀, 닫기 버튼 |
| 웰컴 메시지 | ~20% | 타이포그래피 |
| 추천 질문 칩 | ~28% | 카드 상단 |
| 팝업 헤더 | ~35% | 팝업 타이틀 |
| 섹션 레이블 | ~40% | "제품 문의" 등 |
| 카드 그리드 | ~48% | 2×2 카드 |
| AS 섹션 레이블 | ~54% | "AS·서비스" 등 |
| Active 카드 | ~60% | 선택된 카드 |
| 하단 입력창 | ~96% | Input + 버튼 |

---

## 폰트 처리 가이드

Pretendard는 시스템 설치 폰트가 아닌 경우 Plugin API에서 loadFontAsync 불가.

| 상황 | 처리 방법 |
|---|---|
| Pretendard 설치됨 | `{ family: 'Pretendard', style: 'Regular' }` 사용 |
| Pretendard 미설치 | Inter Regular로 대체 후 사용자 안내 |

**설치 안내 메시지:**
> Pretendard 폰트가 시스템에 설치되어 있지 않아 Inter로 대체했습니다.  
> 설치 후 Figma 재시작 시 Pretendard 적용 가능합니다.  
> 다운로드: https://github.com/orioncactus/pretendard

---

## Description 섹션 표준 구조

```
Description 섹션 (border #333, flex-col)
├── Title 바 (bg:#333, h:60px)
│   └── "Description" (Pretendard Bold 28px, white)
└── contents (flex-row)
    ├── 디자인요청 패널 (w:540px)
    │   ├── 타이틀 바 (bg:#777) → "디자인/퍼블리싱 요청"
    │   └── 항목들 (clone 방식)
    │       └── [번호배지 #1371ee] [내용 텍스트]
    └── 기능개발요청 패널 (w:540px)
        ├── 타이틀 바 (bg:#555) → "기능 개발 요청"
        └── 항목들 (clone 방식)
            └── [번호배지 #ffa800] [내용 텍스트]
```

---

## 작업 완료 체크리스트

- [ ] 이전 화면 Description 내용 확인 완료
- [ ] 신규 화면에서만 등장하는 요소만 항목 도출
- [ ] 디자인/퍼블리싱 항목 — 시각/레이아웃 관점으로 작성
- [ ] 기능 개발 항목 — 인터랙션/기술 관점으로 작성
- [ ] Figma Description 섹션에 항목 작성 완료
- [ ] 화면 위에 번호 배지 배치 완료 (파란=디자인, 주황=기능)
- [ ] 배지 번호와 Description 번호 일치 확인
- [ ] 스크린샷으로 최종 결과물 검증

---

## 프로젝트 참조 정보 (팅크웨어 챗봇)

- **fileKey**: `tceZlp9M1xdYotNrYrc4Lv`
- **번호 배지 스타일 참조 노드**:
  - 디자인 번호 (파란 #1371ee): `78:385`
  - 기능개발 번호 (주황 #ffa800): `78:388`
- **기 정의된 화면 목록**:

| 화면 노드 | 화면명 | 정의된 주요 항목 |
|---|---|---|
| `68:501` | 챗봇 메인화면 (대화전송) | 헤더, 웰컴 메시지, 추천 질문 카드, 내 제품 섹션, 고객지원 2×2 그리드, 하단 입력창, 관련 인터랙션 6종 |
| `17:497` | 챗봇 대화창 (카테고리 팝업) | 카테고리 팝업 레이아웃, 섹션 레이블, 카드 컴포넌트, Active 상태, 오버레이, 팝업 토글/전환/라우팅 처리 |
